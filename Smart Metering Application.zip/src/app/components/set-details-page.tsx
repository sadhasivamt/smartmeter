import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Label } from "./ui/label";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Checkbox } from "./ui/checkbox";
import { ArrowLeft, Download, Cpu } from "lucide-react";
import { toast } from "sonner";

interface SetDetailsPageProps {
  labNumber: number;
  setNumber: number;
  onBack: () => void;
}

type DeviceType = "CH" | "ESME" | "PPMID" | "GSME";

export function SetDetailsPage({ labNumber, setNumber, onBack }: SetDetailsPageProps) {
  const [startDate, setStartDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endDate, setEndDate] = useState("");
  const [endTime, setEndTime] = useState("");
  const [logTypes, setLogTypes] = useState({
    CH: false,
    HAN: false,
  });

  const devices: DeviceType[] = ["CH", "ESME", "PPMID", "GSME"];

  // Get current date in YYYY-MM-DD format
  const getCurrentDate = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Get current time in HH:MM format
  const getCurrentTime = () => {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  const maxDate = getCurrentDate();
  const maxTime = getCurrentTime();

  const validateDates = (): boolean => {
    if (!startDate || !startTime || !endDate || !endTime) {
      toast.error("Please select both start and end date/time");
      return false;
    }

    const startDateTime = new Date(`${startDate}T${startTime}`);
    const endDateTime = new Date(`${endDate}T${endTime}`);
    const now = new Date();

    // Check if dates are in the future
    if (startDateTime > now) {
      toast.error("Start date and time cannot be in the future");
      return false;
    }

    if (endDateTime > now) {
      toast.error("End date and time cannot be in the future");
      return false;
    }

    // Check if start date is less than end date
    if (startDateTime >= endDateTime) {
      toast.error("Start date and time must be less than end date and time");
      return false;
    }

    return true;
  };

  const handleRetrieveLogs = () => {
    if (!validateDates()) {
      return;
    }

    if (!logTypes.CH && !logTypes.HAN) {
      toast.error("Please select at least one log type");
      return;
    }

    // Submit log collection request
    toast.success("Log collection request submitted successfully!");
    
    // In a real app, this would make an API call to submit the log collection request
    // Example: await submitLogCollection({ labNumber, setNumber, startDate, startTime, endDate, endTime, logTypes });
    
    // Reset form after successful submission
    setTimeout(() => {
      setStartDate("");
      setStartTime("");
      setEndDate("");
      setEndTime("");
      setLogTypes({ CH: false, HAN: false });
      toast.info("Form reset. You can submit a new log collection request.");
    }, 2000);
  };

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      {/* Common Header */}
      <div className="fixed top-0 left-0 right-0 bg-white shadow-md z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <h1 className="font-semibold text-center">Automated Logging Solution</h1>
          <p className="text-sm text-gray-600 text-center">Logs Details and Download</p>
        </div>
      </div>

      {/* Back Button and Lab/Set Info */}
      <div className="max-w-6xl mx-auto mb-6 mt-24">
        <div className="bg-white rounded-lg shadow-sm p-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onBack} className="gap-2">
              <ArrowLeft className="size-4" />
              Back
            </Button>
            <div className="flex-1">
              <p className="text-sm text-gray-500">
                Lab {labNumber} - Set {setNumber}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Set Details - Show all devices */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Set Details</CardTitle>
            <CardDescription>All devices in this set</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {devices.map((device) => (
                <div
                  key={device}
                  className="p-6 rounded-lg border-2 border-blue-600 bg-blue-50"
                >
                  <div className="flex flex-col items-center gap-3">
                    <Cpu className="size-8 text-blue-600" />
                    <span className="font-semibold">{device}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Date/Time Selection */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Select Date and Time Range</CardTitle>
            <CardDescription>
              Choose the time period for log retrieval (future dates not allowed)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Start Date/Time */}
              <div className="space-y-2">
                <Label htmlFor="start-date">Start Date</Label>
                <input
                  id="start-date"
                  type="date"
                  max={maxDate}
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="start-time">Start Time</Label>
                <input
                  id="start-time"
                  type="time"
                  max={maxTime}
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                />
              </div>

              {/* End Date/Time */}
              <div className="space-y-2">
                <Label htmlFor="end-date">End Date</Label>
                <input
                  id="end-date"
                  type="date"
                  max={maxDate}
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="end-time">End Time</Label>
                <input
                  id="end-time"
                  type="time"
                  max={maxTime}
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                />
              </div>
            </div>

            {/* Log Type Selection */}
            {startDate && startTime && endDate && endTime && (
              <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
                <Label>Log Type</Label>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="ch-logs"
                    checked={logTypes.CH}
                    onCheckedChange={(checked) => setLogTypes({ ...logTypes, CH: checked as boolean })}
                  />
                  <Label htmlFor="ch-logs" className="cursor-pointer font-normal">
                    CH Logs
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="han-logs"
                    checked={logTypes.HAN}
                    onCheckedChange={(checked) => setLogTypes({ ...logTypes, HAN: checked as boolean })}
                  />
                  <Label htmlFor="han-logs" className="cursor-pointer font-normal">
                    HAN Logs
                  </Label>
                </div>
              </div>
            )}

            {/* Retrieve Button */}
            {startDate && startTime && endDate && endTime && (logTypes.CH || logTypes.HAN) && (
              <Button
                onClick={handleRetrieveLogs}
                className="w-full gap-2"
                size="lg"
              >
                <Download className="size-4" />
                Submit Log Collection
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Selection Summary */}
        {startDate && startTime && endDate && endTime && (
          <Card className="shadow-lg bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-sm">Current Selection Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {startDate && startTime && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Start:</span>
                  <Badge variant="secondary">
                    {new Date(`${startDate}T${startTime}`).toLocaleString()}
                  </Badge>
                </div>
              )}
              {endDate && endTime && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">End:</span>
                  <Badge variant="secondary">
                    {new Date(`${endDate}T${endTime}`).toLocaleString()}
                  </Badge>
                </div>
              )}
              {logTypes.CH && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Log Type:</span>
                  <Badge variant="outline">CH Logs</Badge>
                </div>
              )}
              {logTypes.HAN && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Log Type:</span>
                  <Badge variant="outline">HAN Logs</Badge>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Footer */}
      <div className="max-w-6xl mx-auto mt-6 mb-4">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-center md:text-left">
              <p className="text-sm text-gray-600">
                Copyright © 2025. All rights reserved.
              </p>
            </div>
            <div className="text-center md:text-right">
              <p className="text-sm text-gray-600">
                Contact us: <a href="mailto:support@gmail.com" className="text-blue-600 hover:underline">support@gmail.com</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}