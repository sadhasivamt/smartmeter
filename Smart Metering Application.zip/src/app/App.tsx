import { useState } from "react";
import { AuthPage } from "./components/auth-page";
import { LabsPage } from "./components/labs-page";
import { SetDetailsPage } from "./components/set-details-page";
import { Toaster } from "./components/ui/sonner";

type Page = "auth" | "labs" | "setDetails";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("auth");
  const [userName, setUserName] = useState("");
  const [selectedLab, setSelectedLab] = useState<number>(0);
  const [selectedSet, setSelectedSet] = useState<number>(0);

  // Set page title
  document.title = "Smart Metering Application";

  const handleLoginSuccess = (name: string) => {
    setUserName(name);
    setCurrentPage("labs");
  };

  const handleLogout = () => {
    setCurrentPage("auth");
    setUserName("");
    setSelectedLab(0);
    setSelectedSet(0);
  };

  const handleSelectSet = (labNumber: number, setNumber: number) => {
    setSelectedLab(labNumber);
    setSelectedSet(setNumber);
    setCurrentPage("setDetails");
  };

  const handleBackToLabs = () => {
    setCurrentPage("labs");
  };

  return (
    <>
      {currentPage === "auth" && (
        <AuthPage onLoginSuccess={handleLoginSuccess} />
      )}
      
      {currentPage === "labs" && (
        <LabsPage
          onLogout={handleLogout}
          userName={userName}
          onSelectSet={handleSelectSet}
        />
      )}
      
      {currentPage === "setDetails" && (
        <SetDetailsPage
          labNumber={selectedLab}
          setNumber={selectedSet}
          onBack={handleBackToLabs}
        />
      )}
      
      <Toaster />
    </>
  );
}