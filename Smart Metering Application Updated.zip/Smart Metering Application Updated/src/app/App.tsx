import { useState } from "react";
import { AuthPage } from "./components/auth-page";
import { DashboardPage } from "./components/dashboard-page";
import { LabsPage } from "./components/labs-page";
import { SetDetailsPage } from "./components/set-details-page";
import { DemoModeBanner } from "./components/demo-mode-banner";
import { ApiConfigDialog } from "./components/api-config-dialog";
import { Toaster } from "./components/ui/sonner";

type Page = "auth" | "dashboard" | "labs" | "setDetails";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("auth");
  const [userName, setUserName] = useState("");
  const [selectedLab, setSelectedLab] = useState<number>(0);
  const [selectedLabId, setSelectedLabId] = useState<string>("");
  const [selectedSet, setSelectedSet] = useState<number>(0);
  const [selectedManufacture, setSelectedManufacture] = useState<string>("");
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [showConfigDialog, setShowConfigDialog] = useState(false);

  // Set page title
  document.title = "Automated Logging Solution";

  const handleLoginSuccess = (name: string, demoMode: boolean = false) => {
    setUserName(name);
    setIsDemoMode(demoMode);
    setCurrentPage("dashboard");
  };

  const handleLogout = () => {
    setCurrentPage("auth");
    setUserName("");
    setSelectedLab(0);
    setSelectedLabId("");
    setSelectedSet(0);
    setSelectedManufacture("");
    setIsDemoMode(false);
    // Clear tokens
    localStorage.removeItem("authToken");
    sessionStorage.removeItem("authToken");
    localStorage.removeItem("demoMode");
  };

  const handleNavigateToLabs = () => {
    setCurrentPage("labs");
  };

  const handleSelectSet = (labId: string, labNumber: number, setNumber: number, manufacture: string) => {
    setSelectedLabId(labId);
    setSelectedLab(labNumber);
    setSelectedSet(setNumber);
    setSelectedManufacture(manufacture);
    setCurrentPage("setDetails");
  };

  const handleBackToLabs = () => {
    setCurrentPage("labs");
  };

  const handleBackToDashboard = () => {
    setCurrentPage("dashboard");
  };

  const handleExitDemoMode = () => {
    setShowConfigDialog(true);
  };

  const handleCloseConfigDialog = () => {
    setShowConfigDialog(false);
  };

  return (
    <>
      {/* Demo Mode Banner - Hidden per user request */}
      {/* {isDemoMode && currentPage !== "auth" && (
        <DemoModeBanner onExitDemo={handleExitDemoMode} />
      )} */}

      {currentPage === "auth" && (
        <AuthPage onLoginSuccess={handleLoginSuccess} />
      )}

      {currentPage === "dashboard" && (
        <DashboardPage
          onLogout={handleLogout}
          userName={userName}
          onNavigateToLabs={handleNavigateToLabs}
          isDemoMode={isDemoMode}
        />
      )}
      
      {currentPage === "labs" && (
        <LabsPage
          onLogout={handleLogout}
          userName={userName}
          onSelectSet={handleSelectSet}
          onNavigateToDashboard={handleBackToDashboard}
          isDemoMode={isDemoMode}
        />
      )}
      
      {currentPage === "setDetails" && (
        <SetDetailsPage
          labId={selectedLabId}
          labNumber={selectedLab}
          setNumber={selectedSet}
          manufacture={selectedManufacture}
          onBack={handleBackToLabs}
          onBackToDashboard={handleBackToDashboard}
          userName={userName}
          onLogout={handleLogout}
          onNavigateToLabs={handleNavigateToLabs}
          isDemoMode={isDemoMode}
        />
      )}
      
      {/* Config Dialog when exiting demo mode */}
      <ApiConfigDialog
        isOpen={showConfigDialog}
        onClose={handleCloseConfigDialog}
        endpoint="/log-auth/login"
        errorMessage="Demo Mode is currently active. To connect to your real API, please configure your API endpoint using one of the options below."
      />
      
      <Toaster />
    </>
  );
}