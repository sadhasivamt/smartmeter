# Docker Deployment Guide - Automated Logging Solution (ALS)

This guide provides instructions for building and deploying the Automated Logging Solution application using Docker.

## 📋 Prerequisites

- Docker Engine 20.10 or higher
- Docker Compose 2.0 or higher (optional, for docker-compose deployment)
- At least 2GB of free disk space

## 🏗️ Build Options

### Option 1: Using Docker CLI

#### Build the Docker Image

```bash
# Build the image with a tag
docker build -t als-frontend:latest .

# Build with specific version tag
docker build -t als-frontend:1.0.0 .
```

#### Run the Container

```bash
# Run on port 3000
docker run -d \
  --name als-frontend \
  -p 3000:80 \
  --restart unless-stopped \
  als-frontend:latest

# Run on custom port (e.g., 8080)
docker run -d \
  --name als-frontend \
  -p 8080:80 \
  --restart unless-stopped \
  als-frontend:latest
```

#### Access the Application

Open your browser and navigate to:
- `http://localhost:3000` (or your custom port)

### Option 2: Using Docker Compose

#### Start the Application

```bash
# Start in detached mode
docker-compose up -d

# Start with build
docker-compose up -d --build

# View logs
docker-compose logs -f als-frontend
```

#### Stop the Application

```bash
# Stop containers
docker-compose down

# Stop and remove volumes
docker-compose down -v
```

#### Access the Application

Open your browser and navigate to:
- `http://localhost:3000`

## 🔧 Configuration

### API Proxy Configuration

If you need to connect to a backend API server, modify the `nginx.conf` file:

1. Uncomment the `location` blocks for your API endpoints
2. Replace `http://your-api-server:port` with your actual API server URL
3. Rebuild the Docker image

Example:

```nginx
location /log-auth/ {
    proxy_pass http://api.example.com:8000/log-auth/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

### Environment Variables

You can pass environment variables at runtime:

```bash
docker run -d \
  --name als-frontend \
  -p 3000:80 \
  -e NODE_ENV=production \
  --restart unless-stopped \
  als-frontend:latest
```

## 🐳 Docker Commands Reference

### Container Management

```bash
# List running containers
docker ps

# View container logs
docker logs als-frontend

# Follow logs in real-time
docker logs -f als-frontend

# Stop container
docker stop als-frontend

# Start container
docker start als-frontend

# Restart container
docker restart als-frontend

# Remove container
docker rm als-frontend

# Remove container (force)
docker rm -f als-frontend
```

### Image Management

```bash
# List images
docker images

# Remove image
docker rmi als-frontend:latest

# Remove unused images
docker image prune

# View image details
docker inspect als-frontend:latest
```

### Container Shell Access

```bash
# Execute shell in running container
docker exec -it als-frontend sh

# View nginx configuration
docker exec als-frontend cat /etc/nginx/conf.d/default.conf
```

## 🔍 Troubleshooting

### Container Won't Start

```bash
# Check container logs
docker logs als-frontend

# Check container status
docker ps -a

# Inspect container
docker inspect als-frontend
```

### Port Already in Use

```bash
# Find process using port 3000
lsof -i :3000  # On macOS/Linux
netstat -ano | findstr :3000  # On Windows

# Use a different port
docker run -d --name als-frontend -p 8080:80 als-frontend:latest
```

### Cannot Access Application

1. Check if container is running: `docker ps`
2. Check container logs: `docker logs als-frontend`
3. Verify port mapping: `docker port als-frontend`
4. Test nginx: `docker exec als-frontend nginx -t`

### Application Shows Old Version

```bash
# Rebuild with no cache
docker build --no-cache -t als-frontend:latest .

# Remove old container and start fresh
docker rm -f als-frontend
docker run -d --name als-frontend -p 3000:80 als-frontend:latest
```

## 🚀 Production Deployment

### Best Practices

1. **Use specific version tags** instead of `latest`:
   ```bash
   docker build -t als-frontend:1.0.0 .
   ```

2. **Enable health checks** (already configured in Dockerfile)

3. **Set resource limits**:
   ```bash
   docker run -d \
     --name als-frontend \
     -p 3000:80 \
     --memory="512m" \
     --cpus="1.0" \
     --restart unless-stopped \
     als-frontend:latest
   ```

4. **Use Docker secrets** for sensitive data:
   ```bash
   echo "your-api-key" | docker secret create api_key -
   ```

5. **Enable logging**:
   ```bash
   docker run -d \
     --name als-frontend \
     -p 3000:80 \
     --log-driver json-file \
     --log-opt max-size=10m \
     --log-opt max-file=3 \
     als-frontend:latest
   ```

### HTTPS/SSL Configuration

To enable HTTPS, you can:

1. **Use a reverse proxy** (e.g., Nginx, Traefik, or Caddy)
2. **Modify nginx.conf** to include SSL certificates
3. **Use a cloud provider's load balancer** with SSL termination

Example with custom nginx configuration:

```nginx
server {
    listen 443 ssl http2;
    server_name example.com;
    
    ssl_certificate /etc/ssl/certs/cert.pem;
    ssl_certificate_key /etc/ssl/private/key.pem;
    
    # ... rest of configuration
}
```

## 📊 Monitoring

### View Container Stats

```bash
# Real-time stats
docker stats als-frontend

# Health check status
docker inspect --format='{{.State.Health.Status}}' als-frontend
```

### Check Application Health

```bash
# Manual health check
curl http://localhost:3000

# Check nginx status
docker exec als-frontend nginx -t
```

## 🔄 Updates and Maintenance

### Update Application

```bash
# Pull latest code
git pull origin main

# Rebuild image
docker build -t als-frontend:latest .

# Stop old container
docker stop als-frontend
docker rm als-frontend

# Start new container
docker run -d --name als-frontend -p 3000:80 als-frontend:latest
```

### Backup and Restore

```bash
# Save image to tar file
docker save als-frontend:latest > als-frontend.tar

# Load image from tar file
docker load < als-frontend.tar
```

## 📝 Multi-Stage Build Details

The Dockerfile uses a multi-stage build to optimize the final image size:

1. **Stage 1 (Builder)**: 
   - Uses Node.js 20 Alpine image
   - Installs pnpm and dependencies
   - Builds the application

2. **Stage 2 (Production)**:
   - Uses lightweight Nginx Alpine image
   - Copies only the built files
   - Final image size: ~50MB (compared to ~1GB with Node.js)

## 🌐 Network Configuration

### Connect to External API

If your API is on a different network:

```bash
# Create a custom network
docker network create als-network

# Run API container
docker run -d --name als-api --network als-network api-image:latest

# Run frontend with custom network
docker run -d \
  --name als-frontend \
  --network als-network \
  -p 3000:80 \
  als-frontend:latest
```

### Docker Compose Network

The provided `docker-compose.yml` automatically creates a bridge network for service communication.

## 💡 Tips

- The application runs on **port 80** inside the container
- Map it to any external port: `-p <external>:80`
- Demo mode is enabled by default when API is not configured
- Static assets are cached for 1 year for optimal performance
- Gzip compression is enabled for faster load times

## 📞 Support

For issues related to:
- **Application**: Check application logs and demo mode
- **Docker**: Verify Docker installation and permissions
- **Networking**: Check firewall rules and port availability
- **API Integration**: Verify nginx proxy configuration

## 🔐 Security Notes

- Never commit sensitive data (API keys, passwords) to the image
- Use Docker secrets or environment variables for sensitive configuration
- Keep base images updated: `docker pull node:20-alpine && docker pull nginx:alpine`
- Scan images for vulnerabilities: `docker scan als-frontend:latest`
- Use non-root user in production (optional enhancement)

---

**Version**: 1.0.0  
**Last Updated**: January 2026  
**Maintained By**: ALS Development Team
