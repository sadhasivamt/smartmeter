// Runtime configuration for Smart Metering Application
window.__APP_CONFIG__ = {
    // API Configuration
    API_BASE_URL: "__API_BASE_URL__",
    FEATURE_FLAG_X: "__FEATURE_FLAG_X__"
};