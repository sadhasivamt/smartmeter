#!/bin/bash

set -e

# Substitute environment variables in the config template
if [ -f /usr/share/nginx/html/config.template.js ]; then
    envsubst \
    '${API_BASE_URL} ${FEATURE_FLAG_X}' \
    < /usr/share/nginx/html/config.template.js \
    > /usr/share/nginx/html/config.js 
fi
# Start the application
exec "$@"